# Zadanie 3
# Napisz skrypt, który pozwala wprowadzić 4 liczby calkowite, dodać je i wyświetl wynik na ekranie.
# Wejście i wyjście powinny być zrozumiałe dla użytkownika.

print("------------------ Sumowanie liczb ------------------")
print("Program pyta użytkownika o 4 dowolne liczby całkowite")
print("a następnie zwraca ich sumę.")
print()

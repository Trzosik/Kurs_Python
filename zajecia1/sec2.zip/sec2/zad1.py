# Zadanie 1
# Napisz skrypt, który oblicza ile minut ma rok

# Zadanie 2
# Napisz skrypt, który pobiera dwie wiadomości od użytkownika
# a następnie wyświetla je na ekranie poprzedzone ostrzeżeniem "UWAGA: ..." ​
